<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System Custom codex
 *
 * @copyright   Copyright (C) 2005 - 2017 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die();


class PlgSystemCustomcodex extends JPlugin
{


	public function __construct(&$subject, $config)
	{
		// Calling the parent Constructor
		parent::__construct($subject, $config);

		// Do some extra initialisation in this constructor if required
	}


	public function onAfterDispatch()
  	{

		$app  = JFactory::getApplication();

		if ($app->isClient('administrator'))
		{
			return;
		}

		$document = JFactory::getDocument();
		$code_css = $this->params->get('code_css');
		$code_js  = $this->params->get('code_js');
		$file_css = $this->params->get('file_css');
		$file_js  = $this->params->get('file_js');

		if ( $code_css ) {
			$document->addStyleDeclaration($code_css);
		}

		if ( $code_js ) {
			$document->addScriptDeclaration($code_js);
		}

		if ( $file_css ) {
			$archivoscss = explode(PHP_EOL, $file_css);
			foreach ($archivoscss as $archivocss) {
				$document->addStylesheet($archivocss);
			}
		}

		if ( $file_js ) {
			$archivosjs = explode(PHP_EOL, $file_js);
			foreach ($archivosjs as $archivojs) {
				$document->addScript($archivojs);
			}
		}

		// $document->addCustomTag('<meta property="fb:app_id" content="'.$code_css.'" />');

  	}

}
